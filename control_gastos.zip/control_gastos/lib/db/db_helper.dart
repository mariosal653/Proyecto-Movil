import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/gasto.dart';

class DBHelper {
  static final DBHelper _instance = DBHelper._();
  static Database? _db;
  DBHelper._();

  factory DBHelper() => _instance;

  Future<Database> get database async {
    if (_db != null) return _db!;
    String path = join(await getDatabasesPath(), 'gastos.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, v) {
      return db.execute('''
        CREATE TABLE gastos(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          descripcion TEXT,
          categoria TEXT,
          monto REAL,
          fecha TEXT
        )
      ''');
    });
    return _db!;
  }

  Future<int> insertGasto(Gasto g) async {
    final db = await database;
    return await db.insert('gastos', g.toMap());
  }

  Future<List<Gasto>> getGastos() async {
    final db = await database;
    final maps = await db.query('gastos', orderBy: 'fecha DESC');
    return List.generate(maps.length, (i) => Gasto.fromMap(maps[i]));
  }

  Future<int> updateGasto(Gasto g) async {
    final db = await database;
    return await db.update('gastos', g.toMap(), where: 'id = ?', whereArgs: [g.id]);
  }

  Future<int> deleteGasto(int id) async {
    final db = await database;
    return await db.delete('gastos', where: 'id = ?', whereArgs: [id]);
  }
}
