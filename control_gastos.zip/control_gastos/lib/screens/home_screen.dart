import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../db/db_helper.dart';
import '../models/gasto.dart';
import 'edit_gasto_screen.dart';
import '../widgets/gasto_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final db = DBHelper();
  late Future<List<Gasto>> _gastosFuture;

  @override
  void initState() {
    super.initState();
    _refreshGastos();
  }

  void _refreshGastos() {
    setState(() {
      _gastosFuture = db.getGastos();
    });
  }

  double getTotal(List<Gasto> lista) =>
      lista.fold(0.0, (sum, g) => sum + g.monto);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Control de Gastos')),
      body: FutureBuilder<List<Gasto>>(
        future: _gastosFuture,
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final gastos = snap.data!;
          return Column(
            children: [
              Card(
                margin: const EdgeInsets.all(12),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    'Total Gastos: \$${getTotal(gastos).toStringAsFixed(2)}',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: gastos.length,
                  itemBuilder: (ctx, i) => GastoCard(
                    gasto: gastos[i],
                    onDelete: () async {
                      await db.deleteGasto(gastos[i].id!);
                      _refreshGastos();
                    },
                    onEdit: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => EditGastoScreen(gasto: gastos[i])),
                      );
                      _refreshGastos();
                    },
                  ),
                ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const EditGastoScreen()),
          );
          _refreshGastos();
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
