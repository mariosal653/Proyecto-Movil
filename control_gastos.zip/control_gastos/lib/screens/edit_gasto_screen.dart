import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../db/db_helper.dart';
import '../models/gasto.dart';

class EditGastoScreen extends StatefulWidget {
  final Gasto? gasto;
  const EditGastoScreen({Key? key, this.gasto}) : super(key: key);

  @override
  State<EditGastoScreen> createState() => _EditGastoScreenState();
}

class _EditGastoScreenState extends State<EditGastoScreen> {
  final _formKey = GlobalKey<FormState>();
  final descripcionCtrl = TextEditingController();
  final categoriaCtrl = TextEditingController();
  final montoCtrl = TextEditingController();
  DateTime fecha = DateTime.now();
  final db = DBHelper();

  @override
  void initState() {
    super.initState();
    if (widget.gasto != null) {
      descripcionCtrl.text = widget.gasto!.descripcion;
      categoriaCtrl.text = widget.gasto!.categoria;
      montoCtrl.text = widget.gasto!.monto.toString();
      fecha = widget.gasto!.fecha;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.gasto == null ? 'Nuevo Gasto' : 'Editar Gasto')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: descripcionCtrl,
                decoration: const InputDecoration(labelText: 'Descripción'),
                validator: (v) => v!.isEmpty ? 'Requerido' : null,
              ),
              TextFormField(
                controller: categoriaCtrl,
                decoration: const InputDecoration(labelText: 'Categoría'),
                validator: (v) => v!.isEmpty ? 'Requerido' : null,
              ),
              TextFormField(
                controller: montoCtrl,
                decoration: const InputDecoration(labelText: 'Monto'),
                keyboardType: TextInputType.number,
                validator: (v) {
                  if (v == null || v.isEmpty) return 'Requerido';
                  if (double.tryParse(v) == null) return 'Debe ser número';
                  return null;
                },
              ),
              Row(
                children: [
                  Expanded(child: Text('Fecha: ${DateFormat.yMd().format(fecha)}')),
                  TextButton(
                    onPressed: () async {
                      final d = await showDatePicker(
                        context: context,
                        initialDate: fecha,
                        firstDate: DateTime(2000),
                        lastDate: DateTime.now(),
                      );
                      if (d != null) setState(() => fecha = d);
                    },
                    child: const Text('Seleccionar'),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    final g = Gasto(
                      id: widget.gasto?.id,
                      descripcion: descripcionCtrl.text,
                      categoria: categoriaCtrl.text,
                      monto: double.parse(montoCtrl.text),
                      fecha: fecha,
                    );
                    if (widget.gasto == null) {
                      await db.insertGasto(g);
                    } else {
                      await db.updateGasto(g);
                    }
                    Navigator.pop(context);
                  }
                },
                child: const Text('Guardar'),
              ),
            ],
          ),
        ),
      ),
    );
}
}
