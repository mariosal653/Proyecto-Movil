import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/gasto.dart';

class GastoCard extends StatelessWidget {
  final Gasto gasto;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const GastoCard({
    Key? key,
    required this.gasto,
    required this.onEdit,
    required this.onDelete,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ListTile(
        title: Text(gasto.descripcion),
        subtitle: Text('${gasto.categoria} · ${DateFormat.yMMMd().format(gasto.fecha)}'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(icon: const Icon(Icons.edit), onPressed: onEdit),
            IconButton(icon: const Icon(Icons.delete), onPressed: onDelete),
          ],
        ),
        leading: CircleAvatar(child: Text('\$${gasto.monto.toStringAsFixed(0)}')),
      ),
    );
  }
}
